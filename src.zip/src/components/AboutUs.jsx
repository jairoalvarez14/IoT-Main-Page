const AboutUs = () => {
  return (
    <>
      <section className="max-w-[100%] h-[100vh] flex bg-slate-600">
        <div className="flex w-[100%] h-[100%] justify-center items-center">
          <h1 className="text-[100px] font-bold text-white">About Us!</h1>
        </div>
      </section>
    </>
  );
};

export default AboutUs;
