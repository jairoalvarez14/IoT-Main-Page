const Farms = () => {
  return (
    <>
      <section className="flex max-w-[100%] h-[100vh] bg-slate-400">
        <div className="flex h-[100%] w-[100%] justify-center items-center">
          <h1 className="text-[100px] font-bold">Farms</h1>
        </div>
      </section>
    </>
  );
};

export default Farms;
