const Gallery = () => {
  const photos = [
    "https://logocreator.io/wp-content/uploads/2023/11/google-logo-2020.jpg",
  ];
  return (
    <>
      <section className="max-w-[100%] bg-slate-600 h-[100vh] flex">
        <div className="flex w-[100%] justify-center items-center">
          <div className="slider overflow-hidden">
            <ul className="flex">
              {photos.map((photo) => (
                <li
                  key={photo}
                  className="text-[100px] font-semibold text-white w-[100%] list-none"
                >
                  <img
                    src={photos}
                    alt="Gallery"
                    className="w-[100%] bg-cover bg-center"
                  />
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

/*

  const fetchedUrl =
    "https://images.pexels.com/photos/974314/pexels-photo-974314.jpeg";

  return (
    <>
      <section
        style={{ backgroundImage: `url(${fetchedUrl})` }}
        className="max-w-[100%] h-[100vh] flex bg-cover bg-center"
      >
        <div className="h-[100%] w-[100%] flex justify-center items-center backdrop-blur-sm bg-black/30">
          <h1 className="text-[100px] text-white font-bold">Welcome!</h1>
        </div>
      </section>
    </>
  );
*/

export default Gallery;
